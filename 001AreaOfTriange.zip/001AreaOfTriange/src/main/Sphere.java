package main;

import javax.swing.JOptionPane;

public class Sphere {
	
	private double radius;
	private double surfaceArea;
	private double volume;
	
	public Sphere() {
		setVarsToZero();
	}
	public void setVarsToZero() {			
		setRadius(0, true);
		surfaceArea = 0;
		volume = 0;
	}
	public void setRadius(int rad, boolean set) {
		if (set) {
			radius = rad;
		}else {
			boolean b = true;
			while (b) {
				try {
					radius = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Radius: "));
					b = false;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Enter A Number");
					b = true;
				}
			}
		}
	}
	public void calcsurfaceArea() {
		surfaceArea = 4 * Math.PI * Math.pow(radius, 2);
	}
	public void calcVolume() {
		volume = (4/3) * Math.PI * Math.pow(radius, 3);
	}
	public void showVars() {
		String msg = "Radius: " + radius + "\n" +
				"Surface Area: " + surfaceArea + ", " + "Volume: " + volume;
		JOptionPane.showMessageDialog(null, msg);
	}
}
