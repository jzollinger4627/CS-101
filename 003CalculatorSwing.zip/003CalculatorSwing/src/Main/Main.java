package Main;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;

public class Main {
	
	public static void main(String[] args) {new Main();}
	
	public Main() {
		Calculator BasicCalc = new Calculator();
	}

}
