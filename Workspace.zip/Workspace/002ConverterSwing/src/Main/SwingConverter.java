package Main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class SwingConverter implements ActionListener {

	public static void main(String[] args) throws Exception {new SwingConverter();}
	
	public static int width = 600;
	public static int height = 800;
	private JPanel inputPanel = initInputPanel();
	private JTextField inputText;
	private JTextArea resultArea;
	private JButton enterButton;
	private JButton calcButton;
	private JTextField sphInputText;
	private JTextArea sphResultArea; 
	
	public SwingConverter() {
		JFrame frame = new JFrame("Base Converter - Created by Jacob Zollinger");
		frame.setSize(width, height);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.add(inputPanel);
		
		frame.setVisible(true);
	}

	private JPanel initInputPanel() {
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(600,500));
		panel.setLayout(null);
		
		JLabel label = new JLabel("Enter a base-10 number");
		label.setBounds(50, 50, 230, 30);
		panel.add(label);
		
		label = new JLabel("Enter radius");
		label.setBounds(50, 400, 230, 30);
		panel.add(label);
		
		JTextField text;
		text = inputText = new JTextField();
		text.setBounds(230, 50, 100, 30);
		panel.add(text);
		
		text = sphInputText = new JTextField();
		text.setBounds(230, 400, 100, 30);
		panel.add(text);
		
		JButton button;
		button = enterButton = new JButton("Enter");
		button.setBounds(340, 50, 80, 30);
		button.addActionListener(this);
		button.setActionCommand("Enter");
		panel.add(button);
		
		button = new JButton("Reset");
		button.setBounds(430, 50, 80, 30);
		button.addActionListener(this);
		button.setActionCommand("Reset");
		panel.add(button);
		
		button = calcButton = new JButton("Calc");
		button.setBounds(340, 400, 80, 30);
		button.addActionListener(this);
		button.setActionCommand("Calc");
		panel.add(button);
		
		button = new JButton("Reset");
		button.setBounds(430, 400, 80, 30);
		button.addActionListener(this);
		button.setActionCommand("SphReset");
		panel.add(button);
		
		JTextArea textArea;
		textArea = resultArea = new JTextArea();
		textArea.setBounds(50, 180, 500, 200);
		textArea.setEditable(false);
		textArea.setBackground(Color.WHITE);
		panel.add(textArea);
		
		textArea = sphResultArea = new JTextArea();
		textArea.setBounds(50, 500, 500, 200);
		textArea.setEditable(false);
		textArea.setBackground(Color.WHITE);
		panel.add(textArea);
		
		return panel;
	}
	
	private void showResult() {
		String hexUpperCase;
		inputText.setEnabled(false);
		enterButton.setEnabled(false);
		
		Integer n = getInputNumber(true);
		if (n == null) {
			resultArea.append("Invalid number!");
			return;
		}
		int baseTenNumber = n.intValue();
		resultArea.append("decimal = " + baseTenNumber + "\n");
		resultArea.append("Binary = " + Integer.toString(baseTenNumber, 2) + "\n");
		resultArea.append("octal = " + Integer.toString(baseTenNumber, 8) + "\n");
		//resultArea.append("hexadecimal = " + Integer.toString(baseTenNumber, 16) + "\n");
		
		hexUpperCase = Integer.toString(baseTenNumber, 16).toUpperCase();
		resultArea.append("hexadecimal = " + hexUpperCase);
	}
	
	private Integer getInputNumber(boolean base) {
		if (base) {
			try {
				Integer n = Integer.parseInt(inputText.getText());
				return n;
			}catch(Exception e) {
				return null;
			}
		}else {
			try {
				Integer n = Integer.parseInt(sphInputText.getText());
				return n;
			}catch(Exception e) {
				return null;
			}
		}
	}
	
	private void calc() {
		sphInputText.setEnabled(false);
		calcButton.setEnabled(false);
		
		Integer n = getInputNumber(false);
		if (n == null) {
			sphResultArea.append("Invalid number!");
			return;
		}
		sphResultArea.append("Surface area: " + 4*Math.PI*Math.pow(n, 2) + "\n");
		sphResultArea.append("Volume: " + (4.0/3.0)*Math.PI*Math.pow(n, 3));
		
	}
	
	private void reset() {
		inputText.setText("");
		resultArea.setText("");
		inputText.setEnabled(true);
		enterButton.setEnabled(true);
		inputText.requestFocus();
	}
	
	private void sphReset() {
		sphInputText.setText("");
		sphResultArea.setText("");
		sphInputText.setEnabled(true);
		calcButton.setEnabled(true);
		sphInputText.requestFocus();
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Enter")) {
			showResult();
		}else if (e.getActionCommand().equals("Reset")) {
			reset();
		}else if (e.getActionCommand().equals("Calc")) {
			calc();
		}else if (e.getActionCommand().equals("SphReset")) {
			sphReset();
		}
		
	}
}
