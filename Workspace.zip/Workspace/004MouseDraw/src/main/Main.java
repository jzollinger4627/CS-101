package main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;

public class Main extends JFrame {
	
	Graphics2D g2D;
	
	JPanel drawPanel = new JPanel();
	JPanel colorPanel = new JPanel();
	
	JLabel leftColorLabel = new JLabel();
	JLabel rightColorLabel = new JLabel();
	JLabel[] colorLabel = new JLabel[21];
	
	JMenuBar mainMenuBar = new JMenuBar();
	JMenu fileMenu = new JMenu("File");
	JMenu boardColorMenu = new JMenu("BoardColor");
	JMenu penSizeMenu = new JMenu("PenSize");
	JMenuItem newMenuItem = new JMenuItem("New");
	JMenuItem exitMenuItem = new JMenuItem("Exit");
	JMenuItem blackItem = new JMenuItem("Black");
	JMenuItem yellowItem = new JMenuItem("Yellow");
	JMenuItem redItem = new JMenuItem("Red");
	JMenuItem fineItem = new JMenuItem("Fine");
	JMenuItem smallItem = new JMenuItem("Small");
	JMenuItem mediumItem = new JMenuItem("Medium");
	JMenuItem largeItem = new JMenuItem("Large");

	public Main() {
		setSize(800, 600);
		setLocationRelativeTo(null);
		setResizable(false);
		setTitle("MouseDraw, By: Jacob Zollinger");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				exitForm(e);
			}
		});
		getContentPane().setLayout(new GridBagLayout());
		
		setJMenuBar(mainMenuBar);
		fileMenu.setMnemonic('F');
		mainMenuBar.add(fileMenu);
		fileMenu.add(newMenuItem);
		fileMenu.addSeparator();
		fileMenu.add(exitMenuItem);
		
		boardColorMenu.setMnemonic('B');
		mainMenuBar.add(boardColorMenu);
		boardColorMenu.add(blackItem);
		boardColorMenu.addSeparator();
		boardColorMenu.add(yellowItem);
		boardColorMenu.addSeparator();
		boardColorMenu.add(redItem);
		
		penSizeMenu.setMnemonic('P');
		mainMenuBar.add(penSizeMenu);
		penSizeMenu.add(fineItem);
		penSizeMenu.addSeparator();
		penSizeMenu.add(smallItem);
		penSizeMenu.addSeparator();
		penSizeMenu.add(mediumItem);
		penSizeMenu.addSeparator();
		penSizeMenu.add(largeItem);
		
		drawPanel.setPreferredSize(new Dimension(500,400));
		drawPanel.setBackground(Color.BLACK);
		
		GridBagConstraints GC = new GridBagConstraints();
		GC.gridx = 0;
		GC.gridy = 0;
		GC.gridheight = 2;
		GC.insets = new Insets(10, 10, 10, 10);
		getContentPane().add(drawPanel, GC);
		
		leftColorLabel.setPreferredSize(new Dimension(40,40));
		leftColorLabel.setOpaque(true);
		leftColorLabel.setBackground(Color.BLACK);
		GC = new GridBagConstraints();
		GC.gridx = 1;
		GC.gridy = 0;
		GC.anchor = GridBagConstraints.NORTH;
		GC.insets = new Insets(10, 5, 10, 10);
		getContentPane().add(leftColorLabel, GC);
		
		rightColorLabel.setPreferredSize(new Dimension(40, 40));
		rightColorLabel.setOpaque(true);
		rightColorLabel.setBackground(Color.WHITE);
		GC = new GridBagConstraints();
		GC.gridx = 2;
		GC.gridy = 0;
		GC.anchor = GridBagConstraints.NORTH;
		GC.insets = new Insets(10, 5, 10, 10);
		getContentPane().add(rightColorLabel, GC);
		
		colorPanel.setPreferredSize(new Dimension(120,240));
		colorPanel.setBorder(BorderFactory.createTitledBorder("Colors"));
		GC = new GridBagConstraints();
		GC.gridx = 1;
		GC.gridy = 1;
		GC.gridwidth = 3;
		GC.anchor = GridBagConstraints.NORTH;
		GC.insets = new Insets(10, 5, 10, 10);
		getContentPane().add(colorPanel, GC);
		
		colorPanel.setLayout(new GridBagLayout());
		int j = 0;
		for (int i=0;i<21;i++) {
			if (i-j*3 == 3) {
				j++;
			}
			colorLabel[i] = new JLabel();
			colorLabel[i].setPreferredSize(new Dimension(30,30));
			colorLabel[i].setOpaque(true);
			GC = new GridBagConstraints();
			GC.gridx = i-j*3;
			GC.gridy = j;
			colorPanel.add(colorLabel[i], GC);
			colorLabel[i].addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					Component clickedColor = e.getComponent();
					if (e.getButton() == MouseEvent.BUTTON1) {
						leftColorLabel.setBackground(clickedColor.getBackground());
					}else if (e.getButton() == MouseEvent.BUTTON3) {
						rightColorLabel.setBackground(clickedColor.getBackground());
					}
				}
			});
		}
		colorLabel[0].setBackground(new Color(255,255,255));
		colorLabel[1].setBackground(new Color(175,175,175));
		colorLabel[2].setBackground(new Color(000,000,000));
		colorLabel[3].setBackground(new Color(255,000,000));
		colorLabel[4].setBackground(new Color(175,000,000));
		colorLabel[5].setBackground(new Color(100,000,000));
		colorLabel[6].setBackground(new Color(255,255,000));
		colorLabel[7].setBackground(new Color(175,175,000));
		colorLabel[8].setBackground(new Color(100,100,000));
		colorLabel[9].setBackground(new Color(000,255,000));
		colorLabel[10].setBackground(new Color(000,175,000));
		colorLabel[11].setBackground(new Color(000,100,000));
		colorLabel[12].setBackground(new Color(000,255,255));
		colorLabel[13].setBackground(new Color(000,175,175));
		colorLabel[14].setBackground(new Color(000,100,100));
		colorLabel[15].setBackground(new Color(000,000,255));
		colorLabel[16].setBackground(new Color(000,000,175));
		colorLabel[17].setBackground(new Color(000,000,100));
		colorLabel[18].setBackground(new Color(255,000,255));
		colorLabel[19].setBackground(new Color(175,000,175));
		colorLabel[20].setBackground(new Color(100,000,100));		
		
		pack();
		g2D = (Graphics2D) drawPanel.getGraphics();
		g2D.setStroke(new BasicStroke(1));
		
		newMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newMenuItemActionPerformed(e);
			}
		});
		exitMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitMenuItemActionPerformed(e);
			}
		});
		fineItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				g2D.setStroke(new BasicStroke(1));
			}
			
		});
		smallItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				g2D.setStroke(new BasicStroke(3));
			}
		});
		mediumItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				g2D.setStroke(new BasicStroke(10));
			}
		});
		largeItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				g2D.setStroke(new BasicStroke(25));
			}
		});
		yellowItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				drawPanel.setBackground(Color.YELLOW);
			}
		});
		blackItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				drawPanel.setBackground(Color.BLACK);
			}
		});
		redItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				drawPanel.setBackground(Color.RED);
			}
		});
		drawPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mousePressed(e);
				MP(e);
			}
		});
		drawPanel.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mouseDragged(e);
				MD(e);
			}
		});
		drawPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mouseReleased(e);
				MR(e);
			}
		});
		
	}
	double xPrevious, yPrevious = 0.0d;
	Color drawColor;
	private void MP(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1 || e.getButton() == MouseEvent.BUTTON3) {
			xPrevious = e.getX();
			yPrevious = e.getY();
			if (e.getButton() == MouseEvent.BUTTON1) {
				drawColor = leftColorLabel.getBackground();
			}else {
				drawColor = rightColorLabel.getBackground();
			}
		}
	}
	private void MR(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1 || e.getButton() == MouseEvent.BUTTON3) {
			Line2D.Double myline = new Line2D.Double(xPrevious, yPrevious, e.getX(), e.getY());
			g2D.setPaint(drawColor);
			g2D.draw(myline);
		}
	}
	private void MD(MouseEvent e) {
		Line2D.Double myline = new Line2D.Double(xPrevious, yPrevious, e.getX(), e.getY());
		g2D.setPaint(drawColor);
		g2D.draw(myline);
		xPrevious = e.getX();
		yPrevious = e.getY();
	}
	private void newMenuItemActionPerformed(ActionEvent e) {
		int re = JOptionPane.showConfirmDialog(this, "Are you sure you want to start a New drawing?", "New Drawing",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (re == JOptionPane.YES_OPTION) {
			dispose();
			new Main().setVisible(true);
		}
	}
	private void exitMenuItemActionPerformed(ActionEvent e) {
		exitForm(null);
	}
	private void exitForm(WindowEvent e) {
		int response = JOptionPane.showConfirmDialog(this,"Are you sure you want to exit the program?","Exit Program",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
		if (response == JOptionPane.NO_OPTION) {
			return;
		}
		try {
			g2D.dispose();
		}catch (Exception expect) {}
		System.exit(0);
	}

}
