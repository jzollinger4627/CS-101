package main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Main {
	
	/*
	public static void main(String[] args) {
		reader();
	}
	*/
	
	private static void reader() {
		try {
			FileReader fr = new FileReader("Kennedy_Cuba_Crisis.txt");
			BufferedReader br = new BufferedReader(fr);
			String str;
			while ((str = br.readLine()) != null) {
				System.out.println(str + "\n"); 
			}
			br.close();
		}catch (IOException e) {
			System.out.println(e);
		}
	}
	
	private static void writer() {
		try {
			FileWriter fw = new FileWriter("Credits.txt");
			PrintWriter pw = new PrintWriter(fw);
			pw.println("Couse: 30 credits");
			pw.println("Year: 120 credits");
			pw.println("Degree: 360 credits");
			
			pw.close();
		}catch (IOException e) {
			System.out.println(e);
		}
	}
	
}
