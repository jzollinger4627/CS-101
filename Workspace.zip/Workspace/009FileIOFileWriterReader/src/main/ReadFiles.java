package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class ReadFiles {
	
	public static void main(String[] args) {
		try {
			//reader();
			writer();
		}catch (Exception e) {
			System.out.println(e);
		}
	}
	
	private static void writer() throws FileNotFoundException{
		PrintWriter out = new PrintWriter("output.txt");
		for (int i=1;i<=10;i++) {
			out.println(i);
		}
		out.close();
	}
	
	private static void reader() throws FileNotFoundException {
		File file = new File("delta.txt");
		Scanner in = new Scanner(file);
		int i = 0;
		while (in.hasNextLine()) {
			i++;
			String line = in.nextLine();
			System.out.println(i + "| " + line);
		}
		in.close();
	}

}
