package main;

/**
 * This Fraction class can do basic operation between fraction. This was also
 * to learn the basics in JavaDocs.
 * @author Jacob_Zollinger
 * 
 */

public class Fraction {
	
	//field
	/**
	 * the top number of the fraction
	 */
	private int numerator;
	/**
	 * the bottom number of the fraction
	 */
	private int denominator;
	
	//Constructor Stack
	/**
	 * This Method take a string, example(1/3) and converts it and breaks it apart into a fraction using substrings
	 * @param stringFraction
	 */
	public Fraction(String stringFraction) {
		try {
			int fractionSeperator = stringFraction.indexOf("/");
			if (fractionSeperator == -1) {
				this.numerator = Integer.parseInt(stringFraction);
				this.denominator = 1;
			}else {
				this.numerator = Integer.parseInt(stringFraction.substring(0, fractionSeperator));
				this.denominator = Integer.parseInt(stringFraction.substring(fractionSeperator+1, stringFraction.length()));
			}
		}catch (Exception e) {}
	}
	
	/**
	 * This Method take a Fraction class and prints it out to the console using proper fraction look
	 */
	public void PrintFraction() {
		int lineLength;
		System.out.println(" " + this.numerator + " ");
		if (this.numerator > this.denominator) {
			lineLength = Integer.toString(this.numerator).length();
		}else {
			lineLength = Integer.toString(this.denominator).length();
		}
		for (int i=0;i<lineLength+2;i++) {
			System.out.print("-");
		}
		System.out.println("");
		System.out.println(" " + this.denominator + " ");
	}
	
	//Operations
	/**
	 * this method takes two fractions and adds them, then simplifies them
	 * @param that
	 * @return
	 */
	public Fraction add(Fraction that) {
		Fraction sum = new Fraction(null);
		sum.setNumerator((this.numerator*that.denominator)+(that.numerator*this.denominator));
		sum.setDenominator(this.denominator*that.denominator);
		sum.Sim();
		return sum;
	}
	/**
	 * this method takes two fractions and subtracts them, then simplifies them
	 * @param that
	 * @return
	 */
	public Fraction subtract(Fraction that) {
		Fraction sub = new Fraction(null);
		sub.setNumerator((this.numerator*that.denominator)-(that.numerator*this.denominator));
		sub.setDenominator(this.denominator*that.denominator);
		sub.Sim();
		return sub;
	}
	/**
	 * this method takes two fractions and Multiplies them, then simplifies them
	 * @param that
	 * @return
	 */
	public Fraction multiply(Fraction that) {
		Fraction mult = new Fraction(null);
		mult.setNumerator(this.numerator*that.numerator);
		mult.setDenominator(this.denominator*that.denominator);
		mult.Sim();
		return mult;
	}
	/**
	 * this method takes two fractions and divides them, then simplifies them
	 * @param that
	 * @return
	 */
	public Fraction divide(Fraction that) {
		Fraction mult = new Fraction(null);
		mult.setNumerator(this.numerator*that.denominator);
		mult.setDenominator(this.denominator*that.numerator);
		mult.Sim();
		return mult;
	}
	/**
	 * this method can be applied to a fraction class and then simplifies them
	 */
	public void Sim() {
		boolean broken = false;
		if (this.numerator < 0 && this.denominator < 0) {
			this.numerator *= -1;
			this.denominator *= -1;
		}
		while (!broken) {
			int number;
			if (this.numerator < this.denominator) {
				number = this.numerator;
			}else {
				number = this.numerator;
			}
			broken = true;
			for (int i=2;i<=number;i++) {
				if (this.numerator%i == 0 && this.denominator%i == 0) {
					this.numerator /= i;
					this.denominator /= i;
					broken = false;
					break;
				}
			}
		}
	}
	//Getters and Setters
	/**
	 * gets the numerator of the fraction applied to and returns it
	 * @return
	 */
	public int getNumerator() {
		return numerator;
	}
	/**
	 * sets the numerator of the fraction applied to and returns it
	 * @param numerator
	 */
	public void setNumerator(int numerator) {
		this.numerator = numerator;
	}
	/**
	 * gets the denominator of the fraction applied to
	 * @return
	 */
	public int getDenominator() {
		return denominator;
	}
	/**
	 * sets the denominator of the fraction applied to
	 * @param denominator
	 */
	public void setDenominator(int denominator) {
		this.denominator = denominator;
	}

}
