package main;

import javax.swing.JOptionPane;

public class FractionTester {

	public static void main(String[] args) {
		boolean running = true;
		while (running ) {
			Fraction[] myFraction = new Fraction[3];
			String operation = (JOptionPane.showInputDialog(null, "Enter Operation:(+, -, *, /)")).toLowerCase();
			myFraction[0] = new Fraction(JOptionPane.showInputDialog(null, "Enter first fraction:"));
			myFraction[1] = new Fraction(JOptionPane.showInputDialog(null, "Enter second fraction:"));
			if (operation.equals("+")) {
				myFraction[2] = myFraction[0].add(myFraction[1]);
			}else if (operation.equals("-")) {
				myFraction[2] = myFraction[0].subtract(myFraction[1]);
			}else if (operation.equals("*")) {
				myFraction[2] = myFraction[0].multiply(myFraction[1]);
			}else if (operation.equals("/")) {
				myFraction[2] = myFraction[0].divide(myFraction[1]);
			}
			try {
				JOptionPane.showMessageDialog(null, myFraction[2].getNumerator()+"/"+myFraction[2].getDenominator());
				myFraction[2].PrintFraction();
			}catch (Exception e) {}
			if (JOptionPane.showInputDialog(null,"Do you want to go again:(yes,or no)").toLowerCase().equals("no")) {
				running = false;
			}
		}
	}
}
