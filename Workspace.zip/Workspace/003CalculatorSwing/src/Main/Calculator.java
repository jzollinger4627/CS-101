package Main;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Calculator implements ActionListener {
	
	JFrame frame;
	JTextField textField;
	JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,bdec,badd,bsub,bmul,bdiv,beq,bclr,bbsp,bsqr,bcb,bsqt,blog;
	int operator = 0;
	double firstNumber = 0;
	
	public Calculator() {
		frame = new JFrame("Calculator, Created by Jacob Zollinger");
		frame.setSize(390, 600);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(30,40,330,30);
		textField.setBackground(Color.PINK);
		textField.setEditable(false);
		frame.add(textField);
		
		frame.getContentPane().setBackground(Color.CYAN);
		
		JPanel calculatorInput = new JPanel(); //input
		calculatorInput.setBounds(30, 100, 200, 300);
		calculatorInput.setLayout(new GridLayout(4,4));
		frame.add(calculatorInput);
		
		JPanel functions = new JPanel(); //functions
		functions.setBounds(260, 100, 100, 300);
		functions.setLayout(new GridLayout(4,1));
		frame.add(functions);
		
		JPanel resetButtons = new JPanel();
		resetButtons.setBounds(30,450,330,50);
		resetButtons.setLayout(new GridLayout(1,2));
		frame.add(resetButtons);
		
		b1 = new JButton("1");
		b1.setBackground(Color.PINK);
		b1.addActionListener(this);
		calculatorInput.add(b1);
		b2 = new JButton("2");
		b2.setBackground(Color.PINK);
		b2.addActionListener(this);
		calculatorInput.add(b2);
		b3 = new JButton("3");
		b3.setBackground(Color.PINK);
		b3.addActionListener(this);
		calculatorInput.add(b3);
		bdiv = new JButton("/");
		bdiv.setBackground(Color.PINK);
		bdiv.addActionListener(this);
		calculatorInput.add(bdiv);
		b4 = new JButton("4");
		b4.setBackground(Color.PINK);
		b4.addActionListener(this);
		calculatorInput.add(b4);
		b5 = new JButton("5");
		b5.setBackground(Color.PINK);
		b5.addActionListener(this);
		calculatorInput.add(b5);
		b6 = new JButton("6");
		b6.setBackground(Color.PINK);
		b6.addActionListener(this);
		calculatorInput.add(b6);
		bmul = new JButton("*");
		bmul.setBackground(Color.PINK);
		bmul.addActionListener(this);
		calculatorInput.add(bmul);
		b7 = new JButton("7");
		b7.setBackground(Color.PINK);
		b7.addActionListener(this);
		calculatorInput.add(b7);
		b8 = new JButton("8");
		b8.setBackground(Color.PINK);
		b8.addActionListener(this);
		calculatorInput.add(b8);
		b9 = new JButton("9");
		b9.setBackground(Color.PINK);
		b9.addActionListener(this);
		calculatorInput.add(b9);
		bsub = new JButton("-");
		bsub.setBackground(Color.PINK);
		bsub.addActionListener(this);
		calculatorInput.add(bsub);
		bdec = new JButton(".");
		bdec.setBackground(Color.PINK);
		bdec.addActionListener(this);
		calculatorInput.add(bdec);
		b0 = new JButton("0");
		b0.setBackground(Color.PINK);
		b0.addActionListener(this);
		calculatorInput.add(b0);
		beq = new JButton("=");
		beq.setBackground(Color.PINK);
		beq.addActionListener(this);
		calculatorInput.add(beq);
		badd = new JButton("+");
		badd.setBackground(Color.PINK);
		badd.addActionListener(this);
		calculatorInput.add(badd);
		
		bsqt = new JButton("Square");
		bsqt.setBackground(Color.PINK);
		bsqt.addActionListener(this);
		functions.add(bsqt);
		bcb = new JButton("Cube");
		bcb.setBackground(Color.PINK);
		bcb.addActionListener(this);
		functions.add(bcb);
		bsqr = new JButton("Sq.Root");
		bsqr.setBackground(Color.PINK);
		bsqr.addActionListener(this);
		functions.add(bsqr);
		blog = new JButton("Log(10)");
		blog.setBackground(Color.PINK);
		blog.addActionListener(this);
		functions.add(blog);
		
		bclr = new JButton("Clear");
		bclr.setBackground(Color.PINK);
		bclr.addActionListener(this);
		resetButtons.add(bclr);
		bbsp = new JButton("BackSpace");
		bbsp.setBackground(Color.PINK);
		bbsp.addActionListener(this);
		resetButtons.add(bbsp);
		
		frame.setVisible(true);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b1) {
			textField.setText(textField.getText() + "1");
		}else if (e.getSource() == b2) {
			textField.setText(textField.getText() + "2");
		}else if (e.getSource() == b3) {
			textField.setText(textField.getText() + "3");
		}else if (e.getSource() == b4) {
			textField.setText(textField.getText() + "4");
		}else if (e.getSource() == b5) {
			textField.setText(textField.getText() + "5");
		}else if (e.getSource() == b6) {
			textField.setText(textField.getText() + "6");
		}else if (e.getSource() == b7) {
			textField.setText(textField.getText() + "7");
		}else if (e.getSource() == b8) {
			textField.setText(textField.getText() + "8");
		}else if (e.getSource() == b9) {
			textField.setText(textField.getText() + "9");
		}else if (e.getSource() == b0) {
			textField.setText(textField.getText() + "0");
		}else if (e.getSource() == bdec) {
			int c = 0;
			for (int i=0;i<textField.getText().length();i++) {
				if (textField.getText().charAt(i) == ".".charAt(0)) {
					c++;
				}
			}
			if (c == 0) {
				textField.setText(textField.getText() + ".");
			}
		}else if (e.getSource() == bclr) {
			textField.setText("");
		}else if (e.getSource() == bbsp) {
			try {
				textField.setText(textField.getText().substring(0, textField.getText().length()-1));
			}catch (Exception n) {}
		}else if (e.getSource() == bdiv) {
			if (operator == 0) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 4;
				textField.setText("");
			}else {
				firstNumber = Double.parseDouble(textField.getText())/firstNumber;
				textField.setText("");
			}
		}else if (e.getSource() == bmul) {
			if (operator == 0) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 3;
				textField.setText("");
			}else {
				firstNumber = Double.parseDouble(textField.getText())*firstNumber;
				textField.setText("");
			}
		}else if (e.getSource() == bsub) {
			if (operator == 0) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 2;
				textField.setText("");
			}else {
				firstNumber = Double.parseDouble(textField.getText())-firstNumber;
				textField.setText("");
			}
		}else if (e.getSource() == badd) {
			if (operator == 0) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 1;
				textField.setText("");
			}else {
				firstNumber = Double.parseDouble(textField.getText())+firstNumber;
				textField.setText("");
			}
		}else if (e.getSource() == bsqt) {
			textField.setText(Double.toString(Math.pow(Double.parseDouble(textField.getText()),2)));
		}else if (e.getSource() == bcb) {
			textField.setText(Double.toString(Math.pow(Double.parseDouble(textField.getText()),3)));
		}else if (e.getSource() == bsqr) {
			textField.setText(Double.toString(Math.pow(Double.parseDouble(textField.getText()),0.5)));
		}else if (e.getSource() == blog) {
			textField.setText(Double.toString(Math.log10(Double.parseDouble(textField.getText()))));
		}else if (e.getSource() == beq) {
			switch (operator) {
				case 1:
					textField.setText(Double.toString(firstNumber+Double.parseDouble(textField.getText())));
					break;
				case 2:
					textField.setText(Double.toString(firstNumber-Double.parseDouble(textField.getText())));
					break;
				case 3:
					textField.setText(Double.toString(firstNumber*Double.parseDouble(textField.getText())));
					break;
				case 4:
					textField.setText(Double.toString(firstNumber/Double.parseDouble(textField.getText())));
					break;
			}
			operator = 0;
			firstNumber = 0;
		}else {
			System.out.println("Isn't Done");
		}
	}
}