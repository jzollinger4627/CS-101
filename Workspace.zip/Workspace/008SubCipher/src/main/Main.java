package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class Main extends JFrame {
	
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {new Main();}
	
	public Main() {
		setTitle("Jacob Zollinger's Cipher");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.GRAY);
		getContentPane().setLayout(new GridBagLayout());
		
		GridBagConstraints GC = new GridBagConstraints();
		
		JTextPane decrypted = new JTextPane();
		decrypted.setPreferredSize(new Dimension(450,300));
		decrypted.setBackground(Color.LIGHT_GRAY);
		GC.anchor = GridBagConstraints.NORTH;
		GC.insets = new Insets(20,20,10,20);
		GC.gridx = 0;
		GC.gridy = 0;
		GC.gridwidth = 3;
		GC.gridheight = 1;
		getContentPane().add(decrypted, GC);
		
		JTextPane encrypted = new JTextPane();
		encrypted.setPreferredSize(new Dimension(450,300));
		encrypted.setBackground(Color.LIGHT_GRAY);
		GC.insets = new Insets(10,20,20,20);
		GC.gridy = 3;
		getContentPane().add(encrypted, GC);
		
		JTextField key = new JTextField();
		key.setPreferredSize(new Dimension(100,50));
		key.setBackground(Color.LIGHT_GRAY);
		GC.gridx = 2;
		GC.gridy = 2;
		GC.anchor = GridBagConstraints.EAST;
		GC.gridwidth = 1;
		GC.gridheight = 1;
		GC.insets = new Insets(10,20,10,20);
		add(key, GC);
		
		JButton buttonEncrypt = new JButton("Encrypt");
		buttonEncrypt.setBackground(Color.LIGHT_GRAY);
		buttonEncrypt.setPreferredSize(new Dimension(100,50));
		buttonEncrypt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int numberkey = 0;
				try {
					numberkey = Integer.parseInt(key.getText());
				}catch (Exception b) {
					key.setText("Enter Number");
				}
				Cipher c = new Cipher(decrypted.getText(), numberkey);
				c.encrypt();
				encrypted.setText(c.getEncrypted());
			}
		});
		GC.gridx = 0;
		GC.anchor = GridBagConstraints.WEST;
		add(buttonEncrypt, GC);
		
		JButton buttonDecrypt = new JButton("Decrypt");
		buttonDecrypt.setBackground(Color.LIGHT_GRAY);
		buttonDecrypt.setPreferredSize(new Dimension(100,50));
		buttonDecrypt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int numberkey = 0;
				try {
					numberkey = Integer.parseInt(key.getText());
				}catch (Exception b) {
					key.setText("Enter Number");
				}
				Cipher c = new Cipher(encrypted.getText());
				c.setKey(numberkey);
				c.decrypt();
				decrypted.setText(c.getDecrypted());
			}
		});
		GC.gridx = 1;
		GC.anchor = GridBagConstraints.CENTER;
		add(buttonDecrypt, GC);
		
		
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		
	}

}
