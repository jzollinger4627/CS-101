package main;

public class Cipher {

	private int key;
	private String encrypted = "";
	private String decrypted = "";
	private String alpha = "zebracdfghijklmnopqstuvwxy0123456789.:";
	
	public Cipher(String value, int k) {
		this.key = k;
		this.decrypted = value;
	}
	
	public Cipher(String value) {
		this.encrypted = value;
	}
	
	public void encrypt() {
		this.decrypted = this.decrypted.toLowerCase();
		for (int i=0;i<this.decrypted.length();i++) {
			int e = key;
			int runs = 0;
			for (int k=0;k<alpha.length();k++) {
				if (this.decrypted.charAt(i) == alpha.charAt(k)) {
					e += k;
					break;
				}
				runs++;
			} 
			if (runs == alpha.length()) {
				//this.encrypted += this.decrypted.substring(i, i+1);
				this.encrypted += " ";
			}else {
				if (e >= alpha.length()) {
					e -= alpha.length();
				}else if (e < 0) {
					e += alpha.length();
				}
				this.encrypted += alpha.substring(e, e+1);
			}
		}
	}
	
	public void decrypt() {
		this.encrypted = this.encrypted.toLowerCase();
		for (int i=0;i<this.encrypted.length();i++) {
			int e = -key;
			int runs = 0;
			for (int k=0;k<alpha.length();k++) {
				if (this.encrypted.charAt(i) == alpha.charAt(k)) {
					e += k;
					break;
				}
				runs++;
			} 
			if (runs == alpha.length()) {
				this.decrypted += " ";
			}else {
				if (e >= alpha.length()) {
					e -= alpha.length();
				}else if (e < 0) {
					e += alpha.length();
				}
				this.decrypted += alpha.substring(e, e+1);
			}
		}
	}
	
	public void setKey(int value) {
		this.key = value;
	}
	
	public String getDecrypted() {
		return this.decrypted;
	}
	
	public String getEncrypted() {
		return this.encrypted;
	}
	
}
