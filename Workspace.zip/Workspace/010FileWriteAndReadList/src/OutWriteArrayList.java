import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class OutWriteArrayList {

	public OutWriteArrayList() {
		ArrayList<String> array = new ArrayList<String>();
		String friend = " ";
		
		while (!friend.isEmpty()) {
			friend = JOptionPane.showInputDialog(null, "Enter A Friend");
			if (!friend.isEmpty()) {
				array.add(friend);
			}
		}
		
		try {
			FileWriter fw = new FileWriter("Friends.txt");
			for (int i=0;i<array.size();i++) {
				fw.write(array.get(i).toString()+"\n");
			}
			fw.close();
		}catch (Exception e) {
			System.out.println(e);
		}
	}
	
}
