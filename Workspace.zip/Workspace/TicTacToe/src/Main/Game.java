package Main;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Game extends JPanel implements ActionListener {
	
	public static void main(String[] args) {new Game();}
	
	public JButton[] b = new JButton[9];
	public boolean isPlayerOnesTurn = true;
	private boolean RedWon = false;
	private boolean BlueWon = false;
	
	public Game () {
		JFrame frame = new JFrame("TicTacToe");
		frame.setSize(900, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.add(this);
		setLayout(new GridLayout(3, 3));
		for (int i=0;i<9;i++) {
			b[i] = new JButton();
			b[i].addActionListener(this);
			b[i].setActionCommand("b"+i);
			b[i].setBackground(Color.BLACK);
			add(b[i]);
		}
		frame.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		int isBoardFull = 0;
		boolean reset = false;
		for (int i=0;i<9;i++) {
			if (b[i].getBackground() == Color.BLACK) {
				isBoardFull++;
			}
		}
		if (isBoardFull == 0) {
			for (int i=0;i<9;i++) {
				b[i].setBackground(Color.BLACK);
			}
			reset = true;
			RedWon = false;
			BlueWon = false;
		}
		for (int i=0;i<9;i++) {
			if (e.getActionCommand().equals("b"+i) && !reset) {
				if (b[i].getBackground() == Color.BLACK) {
					if (isPlayerOnesTurn) {
						b[i].setBackground(Color.red);
						isPlayerOnesTurn = false;
					}else {
						b[i].setBackground(Color.blue);
						isPlayerOnesTurn = true;
					}
				}
			}
		}
		check();
		if (RedWon) {
			for (int i=0;i<9;i++) {
				b[i].setBackground(Color.RED);
			}
		}else if (BlueWon) {
			for (int i=0;i<9;i++) {
				b[i].setBackground(Color.BLUE);
			}
		}
	}
	
	private void check() {
		for (int i=0;i<3;i++) {
			if (b[3*i].getBackground() == b[(3*i)+1].getBackground() && b[(3*i)+1].getBackground() == b[(3*i)+2].getBackground()) {
				if (b[3*i].getBackground() == Color.RED) {
					RedWon = true;
				}else if (b[3*i].getBackground() == Color.BLUE) {
					BlueWon = true;
				}
			}
		}
		for (int i=0;i<3;i++) {
			if (b[i].getBackground() == b[i+3].getBackground() && b[i+3].getBackground() == b[i+6].getBackground()) {
				if (b[i].getBackground() == Color.RED) {
					RedWon = true;
				}else if (b[i].getBackground() == Color.BLUE) {
					BlueWon = true;
				}
			}
		}
		if (b[0].getBackground() == b[4].getBackground() && b[4].getBackground() == b[8].getBackground()) {
			if (b[4].getBackground() == Color.RED) {
				RedWon = true;
			}else if (b[4].getBackground() == Color.BLUE) {
				BlueWon = true;
			}
		}
		if (b[2].getBackground() == b[4].getBackground() && b[4].getBackground() == b[6].getBackground()) {
			if (b[4].getBackground() == Color.RED) {
				RedWon = true;
			}else if (b[4].getBackground() == Color.BLUE){
				BlueWon = true;
			}
		}
	}
}
