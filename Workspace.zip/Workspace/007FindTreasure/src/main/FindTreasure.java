package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOError;
import java.net.URL;
import java.util.Random;
import javax.swing.Timer;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class FindTreasure extends JFrame {
	
	JButton button = new JButton("New");
	JLabel labelCounter = new JLabel();
	
	private int sizeX = 5;
	private int sizeY = 3;
	private int total = sizeX*sizeY;
	
	private int counter = 0;
	
	JPanel[][] board = new JPanel[sizeX][sizeY];
	
	Random numberGenerator = new Random();
	int treasureLocation;
	int bombLocation;
	
	public FindTreasure() {
		setTitle("Find The Treasure, By:Jacob Zollinger, 11/18");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.YELLOW);
		getContentPane().setLayout(new GridBagLayout());
		
		GridBagConstraints GC;
		
		int e = 0;
		for (int i=0;i<total;i++) {
			board[i-e*(sizeX)][e] = new JPanel();
			board[i-e*sizeX][e].setPreferredSize(new Dimension(225, 225));
			board[i-e*sizeX][e].setLayout(null);
			GC = new GridBagConstraints();
			GC.gridx = i-e*sizeX;
			GC.gridy = e;
			GC.gridwidth = 1;
			GC.anchor = GridBagConstraints.NORTH;
			GC.insets.set(20, 20, 20, 20);
			add(board[i-e*sizeX][e], GC);
			board[i-e*sizeX][e].addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					super.mouseClicked(e);
					clicked(e);
				}
			});
			board[i-e*sizeX][e].setBackground(Color.RED);
			if (i == ((sizeX-1)+(e*sizeX))) {
				e++;
			}
		}
		
		button.setPreferredSize(new Dimension(200, 50));
		button.setBackground(Color.RED);
		GC = new GridBagConstraints();
		GC.gridx = sizeX/2;
		GC.gridy = sizeY;
		GC.anchor = GridBagConstraints.NORTH;
		GC.insets.set(20, 20, 20, 20);
		getContentPane().add(button, GC);
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				for (int i=0;i<total;i++) {
					panelBackground(i, Color.RED);
				}
				treasureLocation = numberGenerator.nextInt(total);
				do {
					bombLocation = numberGenerator.nextInt(total);
				}while (bombLocation == treasureLocation);
				counter = 0;
				labelCounter.setText("Tries: "+counter);
			}
		});
		
		labelCounter.setPreferredSize(new Dimension(200, 50));
		labelCounter.setText("Tries: "+counter);
		labelCounter.setBackground(Color.RED);
		GC = new GridBagConstraints();
		GC.gridx = (sizeX/2)-1;
		GC.gridy = sizeY;
		GC.anchor = GridBagConstraints.NORTH;
		GC.insets.set(20, 20, 20, 20);
		getContentPane().add(labelCounter, GC);
		
		treasureLocation = numberGenerator.nextInt(total);
		do {
			bombLocation = numberGenerator.nextInt(total);
		}while (bombLocation == treasureLocation);
		pack();
		setLocationRelativeTo(null);
	}
	private void clicked(MouseEvent value) {
		int e = 0;
		for (int i=0;i<total;i++) {
			if (value.getSource() == board[i-e*sizeX][e]) {
				if (treasureLocation == i) {
					foundTreasure(i);
					counter++;
					labelCounter.setText("Tries: "+counter);
				}else if (bombLocation == i) {
					BufferedImage bombPicture = null;
					Graphics g = board[bombLocation-(bombLocation/sizeX)*sizeX][bombLocation/sizeX].getGraphics();
					try {
						bombPicture = ImageIO.read(this.getClass().getResource("/bob2.gif"));
					}catch (Exception w) {}
					g.drawImage(bombPicture, 0, 0, null);
					foundBomb.start();
				}else { 
					panelBackground(i, Color.WHITE);
					counter++;
					labelCounter.setText("Tries: "+counter);
				}
			}
			if (i == ((sizeX-1)+(e*sizeX))) {
				e++;
			}
		}
	}
	private void foundTreasure(int i) {
		BufferedImage treasurePicture = null;
		Graphics g = board[i-(i/sizeX)*sizeX][i/sizeX].getGraphics();
		try {
			treasurePicture = ImageIO.read(this.getClass().getResource("/bob.gif"));
		}catch (Exception e) {}
		g.drawImage(treasurePicture, 0, 0, null);
	}
	private void panelBackground(int panel,Color color) {
		Graphics g = board[panel-(panel/sizeX)*sizeX][panel/sizeX].getGraphics();
		g.setColor(color);
		g.fillRect(0, 0, 225, 225);
	}
	private Timer foundBomb = new Timer(1000, new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			for (int i=0;i<total;i++) {
				panelBackground(i, Color.RED);
			}
			treasureLocation = numberGenerator.nextInt(total);
			do {
				bombLocation = numberGenerator.nextInt(total);
			}while (bombLocation == treasureLocation);
			foundBomb.stop();
		}
	});
	
}
