package main;

import javax.swing.JOptionPane;

public class Runner {
	/*
	 * Circle: input r, calculate circumference, area
	 * Rectangle: input side A, B, calc, perimeter, area and diagonal
	 * Cuboid
	 */
	
	private static boolean running = true;

	public static void main(String[] args) {
		
		JOptionPane.showMessageDialog(null, "Welcome to Jacob Zollinger Program, A3, 9/14/18");
		
		while (running) {
			String shape = JOptionPane.showInputDialog("Enter Shape(Rectangle, Triangle, Circle, Cuboid, Sphere, Exit): ");
			if (shape.equals("rectangle") || shape.equals("Rectangle")){
				Rectangle rect = new Rectangle();
				rect.setSides(0, 0, false);
				rect.CalcPerimeter();
				rect.CalcArea();
				rect.CalcDiagonal();
				rect.showVars();
			}else if (shape.equals("triangle") || shape.equals("Triangle")) {
				Triangle tri = new Triangle();
				tri.setSides(0, 0, 0, false);
				tri.calcPerimeter();
				tri.calcArea();
				tri.calcAngles();
				tri.showVars();
			}else if (shape.equals("circle") || shape.equals("Circle")){
				Circle cir = new Circle();
				cir.setRadius(0, false);
				cir.calcCircumfrence();
				cir.calcArea();
				cir.showVars();
			}else if (shape.equals("cuboid") || shape.equals("Cuboid")) {
				Cuboid cuboid = new Cuboid();
				cuboid.setSides(0, 0, 0, false);
				cuboid.CalcSurfaceArea();
				cuboid.CalcVolume();
				cuboid.showVars();
			}else if (shape.equals("sphere") || shape.equals("Sphere")) {
				Sphere sphere = new Sphere();
				sphere.setRadius(0, false);
				sphere.calcsurfaceArea();
				sphere.calcVolume();
				sphere.showVars();
			}else if (shape.equals("exit") || shape.equals("Exit")) {
				running = false;
			}else {
				JOptionPane.showMessageDialog(null, "Please Enter An Option");
			}
		}
		JOptionPane.showMessageDialog(null, "Good Bye!");
	}
}
