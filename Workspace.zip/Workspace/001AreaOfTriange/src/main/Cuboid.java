package main;

import javax.swing.JOptionPane;

public class Cuboid {
	
	private double sideA, sideB, sideC;
	private double volume;
	private double surfaceArea;
	
	public Cuboid() {
		setVarsToZero();
	}
	public void setVarsToZero() {
		setSides(0,0,0,true);
		volume = 0;
		surfaceArea = 0;
	}
	public void showVars() {
		String msg = "Width, Depth, Height: " + sideA + " " + sideB + " " + sideC + "\n" +
				"Volume: " + volume + ", " + "Surface Area: " + surfaceArea;
		JOptionPane.showMessageDialog(null, msg);
	}
	public void setSides(double i, double j, double k, boolean set) {
		if (set) {
			sideA = i;
			sideB = j;
			sideC = k;
		} else {
			boolean b = true;
			while (b) {
				try {
					sideA = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Width: "));
					b = false;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Enter A Number");
					b = true;
				}
			}
			b = true;
			while (b) {
				try {
					sideB = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Depth: "));
					b = false;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Enter A Number");
					b = true;
				}
			}
			b = true;
			while (b) {
				try {
					sideC = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Height: "));
					b = false;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Enter A Number");
					b = true;
				}
			}
		}
	}
	public void CalcVolume() {
		volume = sideA*sideB*sideC;
	}
	public void CalcSurfaceArea() {
		surfaceArea = ((sideA * sideB)* 2) + ((sideA * sideC)* 2) + ((sideC * sideB)* 2);
	}
}
