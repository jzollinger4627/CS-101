package main;

import javax.swing.JOptionPane;

public class Rectangle {
	
	private double sideA, sideB;
	private double perimeter;
	private double theArea;
	private double diagonal;

	public Rectangle() {
		setVarsToZero();
	}
	public void setVarsToZero() {
		setSides(0,0,true);
		perimeter = 0;
		theArea = 0;
	}
	public void showVars() {
		String msg = "Side A,B: " + sideA + " " + sideB + "\n" +
				"Perimeter: " + perimeter + ", " + "Area: " + theArea + "\n" +
				"Diagonal: " + diagonal;
		JOptionPane.showMessageDialog(null, msg);
	}
	public void setSides(double i, double j, boolean set) {
		if (set) {
			sideA = i;
			sideB = j;
		} else {
			boolean b = true;
			while (b) {
				try {
					sideA = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Side A: "));
					b = false;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Enter A Number");
					b = true;
				}
			}
			b = true;
			while (b) {
				try {
					sideB = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Side B: "));
					b = false;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Enter A Number");
					b = true;
				}
			}
		}
	}
	public void CalcPerimeter() {
		perimeter = ((sideA*2)+(sideB*2));
	}
	public void CalcArea() {
		theArea = (sideA*sideB);
	}
	public void CalcDiagonal() {
		diagonal = Math.sqrt(Math.pow(sideA, 2) + Math.pow(sideB, 2));
	}
	
}
