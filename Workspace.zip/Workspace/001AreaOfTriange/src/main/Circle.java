package main;

import javax.swing.JOptionPane;

public class Circle {

	private double radius;
	private double circumference;
	private double area;
	
	public Circle() {
		setVarsToZero();
	}
	public void setVarsToZero() {
		setRadius(0, true);
		circumference = 0;
		area = 0;
	}
	public void setRadius(int rad, boolean set) {
		if (set) {
			radius = rad;
		}else {
			boolean b = true;
			while (b) {
				try {
					radius = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Radius: "));
					b = false;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Enter A Number");
					b = true;
				}
			}
		}
	}
	public void calcCircumfrence() {
		circumference = (radius * 2) * Math.PI;
	}
	public void calcArea() {
		area = Math.pow((Math.PI * radius), 2);
	}
	public void showVars() {
		String msg = "Radius: " + radius + "\n" +
				"Circumference: " + circumference + ", " + "Area: " + area;
		JOptionPane.showMessageDialog(null, msg);
	}
}
