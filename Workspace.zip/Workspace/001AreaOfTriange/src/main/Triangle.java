package main;

import javax.swing.JOptionPane;

public class Triangle {
	
	private double sideA, sideB, sideC;
	private double angleA, angleB, angleC;
	private double perimeter;
	private double theArea;

	public Triangle() {
		setVarsToZero();
	}
	public void setVarsToZero() {
		setSides(0,0,0,true);
		perimeter = 0;
		theArea = 0;
	}
	public void setSides(double i, double j, double k, boolean set) {
		if (set) {
			sideA = i;
			sideB = j;
			sideC = k;
		}else {
			boolean b = true;
			while (b) {
				try {
					sideA = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Side A: "));
					b = false;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Enter A Number");
					b = true;
				}
			}
			b = true;
			while (b) {
				try {
					sideB = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Side B: "));
					b = false;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Enter A Number");
					b = true;
				}
			}
			b = true;
			while (b) {
				try {
					sideC = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Side C: "));
					b = false;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Enter A Number");
					b = true;
				}
			}
		}
	}
	public void calcAngles() {
		angleC = Math.toDegrees(Math.acos((Math.pow(sideA, 2.0) + Math.pow(sideB, 2.0) - Math.pow(sideC, 2.0)) / (2 * sideA * sideB)));
		angleA = Math.toDegrees(Math.acos((Math.pow(sideB, 2.0) + Math.pow(sideC, 2.0) - Math.pow(sideA, 2.0)) / (2 * sideB * sideC)));
		angleB = Math.toDegrees(Math.acos((Math.pow(sideC, 2.0) + Math.pow(sideA, 2.0) - Math.pow(sideB, 2.0)) / (2 * sideC * sideA)));
		
	}
	public void showVars() {
		String msg = "Side A,B,C: " + sideA + " " + sideB + " " + sideC + "\n" +
				"Angle A,B,C: " + angleA + " " + angleB + " " + angleC + "\n" +
				"perimeter: " + perimeter + ", " + "Area: " + theArea;
		JOptionPane.showMessageDialog(null, msg);
	}
	public void calcPerimeter() {
		perimeter = sideA + sideB + sideC;
	}
	public void calcArea() {
		double s;
		s = perimeter/2;
		theArea = Math.sqrt(s*(s-sideA)*(s-sideB)*(s-sideC));
	}
}
